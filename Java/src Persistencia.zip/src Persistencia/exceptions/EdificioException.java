package exceptions;

public class EdificioException extends Exception {

	private static final long serialVersionUID = 9018648492209155948L;

	public EdificioException(String mensaje) {
		super(mensaje);
	}
}
