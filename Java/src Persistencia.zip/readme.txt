Acá iría lo que se hace en Eclipse
